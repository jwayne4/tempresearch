import scrapy
import json
import csv
from datetime import datetime





class G2gSpider(scrapy.Spider):
    name = 'g2g'
    start_urls = ['http://www.g2g.com/']

    headers = {
    "Accept" : "application/json, text/plain, */*",
    "Origin" : "https://www.g2g.com",
    "Referer" : "https://www.g2g.com/",
    "Accept-Language" : "en-CA,en-US;q=0.9,en;q=0.8",
    "Host": "sls.g2g.com",
    "User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15",
    "Authorization" : "null",
    "Accept-Encoding" : "gzip, deflate, br",
    "Connection" : "keep-alive",
    "x-api-key": "0DWATzuevY8r91rPCySTl91p2Odp6itK23sOskIX"
    }


    def parse(self, response):
        urls = ("https://sls.g2g.com/offer/search?service_id=lgc_service_1&brand_id=lgc_game_27266&sort=recommended&page_size=48&currency=CAD&country=CA",
                "https://sls.g2g.com/offer/search?service_id=lgc_service_1&brand_id=lgc_game_27266&sort=recommended&page=2&page_size=48&currency=CAD&country=CA")


        for url in urls:
            yield scrapy.Request(url,
                callback = self.parse_api,
                headers=self.headers)


    def parse_api(self,response):
         raw_data = response.body
         data = json.loads(raw_data)
         dt = datetime.now()
         with open('./g2g_newworld_tracking_data.csv', 'a', encoding='UTF8', newline='') as f:

            fieldnames = ['Title','Name','Seller_ID','QTY','Currency','Price','Time']
            writer = csv.DictWriter(f,fieldnames)
            writer.writeheader()
            for i in data["payload"]["results"]:




                clean_data= [{
                    'Title': i['title'],
                    'Name': i['username'],
                    'Seller_ID': i['seller_id'],
                    'QTY': i['available_qty'],
                    'Currency': i['offer_currency'],
                    'Price': i['unit_price'],
                    'Time': dt}]


                print(clean_data)
                writer.writerows(clean_data)


            print('#'*100+'\nData has been retrived and added\n'+'#'*100)